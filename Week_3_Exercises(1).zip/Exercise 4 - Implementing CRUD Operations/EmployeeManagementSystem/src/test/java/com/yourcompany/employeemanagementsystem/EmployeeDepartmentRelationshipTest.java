package com.yourcompany.employeemanagementsystem;

import com.yourcompany.employeemanagementsystem.entity.Department;
import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.repository.DepartmentRepository;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;

@SpringBootTest
@Transactional
@Rollback
public class EmployeeDepartmentRelationshipTest {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

//    @Test
//    public void testCreateDepartmentWithEmployees() {
//        // Create a new department
//        Department department = new Department();
//        department.setName("HR");
//
//        // Create new employees and associate them with the department
//        Employee emp1 = new Employee(null, "John Doe", "john@example.com", department);
//        Employee emp2 = new Employee(null, "Jane Smith", "jane@example.com", department);
//
//        // Add employees to the department
//        department.setEmployees(Arrays.asList(emp1, emp2));
//
//        // Save the department (which should cascade to employees)
//        Department savedDepartment = departmentRepository.save(department);
//
//        // Assertions
//        Assertions.assertNotNull(savedDepartment.getId());
//        Assertions.assertEquals(2, savedDepartment.getEmployees().size());
//    }

    @Test
    public void testAddEmployeesToExistingDepartment() {
        // Assume department is already saved
        Department department = departmentRepository.findById(1L).orElseThrow();

        // Create new employees
        Employee emp3 = new Employee(null, "Alice Brown", "alice@example.com", department);

        // Save employee (should automatically link with the department)
        Employee savedEmployee = employeeRepository.save(emp3);

        // Assertions
        Assertions.assertNotNull(savedEmployee.getId());
        Assertions.assertEquals("HR", savedEmployee.getDepartment().getName());
    }

    @Test
    public void testFetchEmployeesWithDepartment() {
        // Fetch all employees
        List<Employee> employees = employeeRepository.findAll();

        // Assertions
        Assertions.assertFalse(employees.isEmpty());
        Assertions.assertNotNull(employees.get(0).getDepartment());
    }

    @Test
    public void testDeleteDepartmentAndCascadeToEmployees() {
        // Assume department is already saved
        Department department = departmentRepository.findById(1L).orElseThrow();

        // Delete the department
        departmentRepository.delete(department);

        // Fetch employees linked to this department
        List<Employee> employees = employeeRepository.findByDepartment(department);

        // Assertions
        Assertions.assertTrue(employees.isEmpty());
    }
}