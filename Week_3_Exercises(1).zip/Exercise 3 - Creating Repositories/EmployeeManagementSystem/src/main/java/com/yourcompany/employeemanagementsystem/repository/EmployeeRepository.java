package com.yourcompany.employeemanagementsystem.repository;

import com.yourcompany.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Custom query method to find employees by department ID
    List<Employee> findByDepartmentId(Long departmentId);

    // Custom query method to find an employee by email
    Employee findByEmail(String email);
}
