package com.yourcompany.employeemanagementsystem.repository;

import com.yourcompany.employeemanagementsystem.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    // Custom query method to find a department by name
    Department findByName(String name);
}
