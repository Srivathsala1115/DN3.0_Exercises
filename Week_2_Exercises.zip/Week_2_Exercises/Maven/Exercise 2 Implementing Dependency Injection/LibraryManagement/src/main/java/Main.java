import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.library.service.BookService;

public class Main {
    public static void main(String[] args) {
        // Load the Spring context
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        // Retrieve the BookService bean
        BookService bookService = (BookService) context.getBean("bookService");

        // Check if BookService and BookRepository are injected properly
        if (bookService != null) {
            System.out.println("BookService bean has been created and injected.");
        } else {
            System.out.println("Failed to create BookService bean.");
        }
    }
}
