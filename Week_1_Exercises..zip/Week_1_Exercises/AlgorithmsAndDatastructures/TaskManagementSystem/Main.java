package TaskManagementSystem;

public class Main {

    public static void main(String[] args) {
        // Initialize the Task Management System
        TaskLinkedList taskList = new TaskLinkedList();

        // Add tasks
        taskList.addTask(new Task(1, "Design database schema", "Pending"));
        taskList.addTask(new Task(2, "Develop API endpoints", "In Progress"));
        taskList.addTask(new Task(3, "Create frontend layout", "Pending"));
        taskList.addTask(new Task(4, "Test application", "Not Started"));

        // Traverse and display all tasks
        System.out.println("All tasks:");
        taskList.traverseTasks();

        // Search for a task by ID
        Task task = taskList.searchTask(2);
        if (task != null) {
            System.out.println("\nTask found: " + task.getTaskName() + ", Status: " + task.getStatus());
        } else {
            System.out.println("\nTask not found.");
        }

        // Delete a task by ID
        boolean deleted = taskList.deleteTask(3);
        if (deleted) {
            System.out.println("\nTask with ID 3 deleted.");
        } else {
            System.out.println("\nTask with ID 3 not found.");
        }

        // Display all tasks after deletion
        System.out.println("\nAll tasks after deletion:");
        taskList.traverseTasks();
    }
}
