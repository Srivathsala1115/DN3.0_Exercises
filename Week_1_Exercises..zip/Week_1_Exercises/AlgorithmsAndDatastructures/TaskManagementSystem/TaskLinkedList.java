package TaskManagementSystem;

public class TaskLinkedList {
    private Node head;

    public TaskLinkedList() {
        this.head = null;
    }

    // Add a task to the linked list
    public void addTask(Task task) {
        Node newNode = new Node(task);
        newNode.next = head;
        head = newNode;
    }

    // Search for a task by ID
    public Task searchTask(int taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId() == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null; // Task not found
    }

    // Traverse and display all tasks
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println("Task ID: " + current.task.getTaskId() +
                    ", Task Name: " + current.task.getTaskName() +
                    ", Status: " + current.task.getStatus());
            current = current.next;
        }
    }

    // Delete a task by ID
    public boolean deleteTask(int taskId) {
        Node current = head;
        Node previous = null;

        while (current != null) {
            if (current.task.getTaskId() == taskId) {
                if (previous == null) {
                    head = current.next; // Task to delete is the head
                } else {
                    previous.next = current.next;
                }
                return true; // Task deleted
            }
            previous = current;
            current = current.next;
        }
        return false; // Task not found
    }
}

