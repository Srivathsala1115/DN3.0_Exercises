package SortingAlgorithms;

public class Main {

    public static void main(String[] args) {
        Order[] orders = {
                new Order(1, "Alice", 250.0),
                new Order(2, "Bob", 150.0),
                new Order(3, "Charlie", 300.0),
                new Order(4, "David", 200.0),
                new Order(5, "Eve", 100.0)
        };

        // Sorting using Bubble Sort
        System.out.println("Orders sorted by Bubble Sort:");
        SortOrders.bubbleSort(orders);
        printOrders(orders);

        // Reset the array to unsorted state
        orders = new Order[]{
                new Order(1, "Alice", 250.0),
                new Order(2, "Bob", 150.0),
                new Order(3, "Charlie", 300.0),
                new Order(4, "David", 200.0),
                new Order(5, "Eve", 100.0)
        };

        // Sorting using Quick Sort
        System.out.println("\nOrders sorted by Quick Sort:");
        SortOrders.quickSort(orders, 0, orders.length - 1);
        printOrders(orders);
    }

    // Method to print the orders
    private static void printOrders(Order[] orders) {
        for (Order order : orders) {
            System.out.println("Order ID: " + order.getOrderId() +
                    ", Customer Name: " + order.getCustomerName() +
                    ", Total Price: $" + order.getTotalPrice());
        }
    }
}
