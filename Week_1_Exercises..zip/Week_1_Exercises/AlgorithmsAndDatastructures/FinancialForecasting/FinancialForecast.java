package FinancialForecasting;

public class FinancialForecast {

    // Method to calculate future value using recursion
    public double calculateFutureValue(double presentValue, double rate, int periods) {
        // Base case: if there are no more periods, return the present value
        if (periods == 0) {
            return presentValue;
        }

        // Recursive step: calculate future value for the next period
        return calculateFutureValue(presentValue * (1 + rate), rate, periods - 1);
    }
    public double calculateFutureValueIterative(double presentValue, double rate, int periods) {
        double futureValue = presentValue;

        for (int i = 0; i < periods; i++) {
            futureValue *= (1 + rate);
        }

        return futureValue;
    }
    public static void main(String[] args) {
        FinancialForecast forecast = new FinancialForecast();

        double presentValue = 1000.0;
        double rate = 0.05; // 5% growth rate
        int periods = 5;

        double futureValue = forecast.calculateFutureValue(presentValue, rate, periods);
        double futureValue_1 = forecast.calculateFutureValueIterative(presentValue, rate, periods);
        System.out.println("The future value by calculateFutureValue function is: " + futureValue);
        System.out.println("The future value by calculateFutureValueIterative is: " + futureValue_1);


    }
}
