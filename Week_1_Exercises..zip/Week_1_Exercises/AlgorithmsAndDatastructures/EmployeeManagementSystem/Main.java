package EmployeeManagementSystem;

public class Main {

    public static void main(String[] args) {
        // Initialize the Employee Management System with a capacity of 5
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        // Add employees
        ems.addEmployee(new Employee(1, "Srivathsala Jay", "Manager", 75000));
        ems.addEmployee(new Employee(2, "Lakshmy Ram", "Developer", 60000));
        ems.addEmployee(new Employee(3, "Preethi Rick", "Designer", 55000));
        ems.addEmployee(new Employee(4, "Aparna", "Tester", 50000));
        ems.addEmployee(new Employee(5, "Krithi", "HR", 45000));

        // Attempt to add another employee (should fail as the array is full)
        boolean added = ems.addEmployee(new Employee(6, "Shree Gnans", "Admin", 40000));
        if (!added) {
            System.out.println("Cannot add more employees, the array is full.");
        }

        // Search for an employee by ID
        Employee employee = ems.searchEmployee(3);
        if (employee != null) {
            System.out.println("\nEmployee found: " + employee.getName() + ", Position: " + employee.getPosition());
        } else {
            System.out.println("\nEmployee not found.");
        }

        // Traverse and display all employees
        System.out.println("\nAll employees:");
        ems.traverseEmployees();

        // Delete an employee by ID
        boolean deleted = ems.deleteEmployee(2);
        if (deleted) {
            System.out.println("\nEmployee with ID 2 deleted.");
        } else {
            System.out.println("\nEmployee with ID 2 not found.");
        }

        // Display all employees after deletion
        System.out.println("\nAll employees after deletion:");
        ems.traverseEmployees();
    }
}
