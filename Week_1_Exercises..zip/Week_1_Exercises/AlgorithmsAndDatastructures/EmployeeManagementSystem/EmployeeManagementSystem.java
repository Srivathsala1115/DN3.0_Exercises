package EmployeeManagementSystem;

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int count;

    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        count = 0;
    }

    // Add an employee
    public boolean addEmployee(Employee employee) {
        if (count >= employees.length) {
            return false; // Array is full
        }
        employees[count++] = employee;
        return true;
    }

    // Search for an employee by ID
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null; // Employee not found
    }

    // Traverse all employees
    public void traverseEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println("ID: " + employees[i].getEmployeeId() +
                    ", Name: " + employees[i].getName() +
                    ", Position: " + employees[i].getPosition() +
                    ", Salary: " + employees[i].getSalary());
        }
    }

    // Delete an employee by ID
    public boolean deleteEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                employees[i] = employees[--count]; // Replace with last employee and reduce count
                employees[count] = null; // Optional: clear last element
                return true;
            }
        }
        return false; // Employee not found
    }
}
