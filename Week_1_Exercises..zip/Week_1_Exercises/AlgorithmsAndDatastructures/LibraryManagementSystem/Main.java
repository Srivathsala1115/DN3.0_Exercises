package LibraryManagementSystem;

public class Main {

    public static void main(String[] args) {
        // Sample list of books
        Book[] books = {
                new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"),
                new Book(2, "To Kill a Mockingbird", "Harper Lee"),
                new Book(3, "1984", "George Orwell"),
                new Book(4, "Pride and Prejudice", "Jane Austen"),
                new Book(5, "The Catcher in the Rye", "J.D. Salinger")
        };

        // Initialize the Library
        Library library = new Library(books);

        // Linear search by title
        String searchTitle = "1984";
        Book foundBook = library.linearSearchByTitle(searchTitle);
        if (foundBook != null) {
            System.out.println("Book found (Linear Search): " + foundBook.getTitle() +
                    " by " + foundBook.getAuthor());
        } else {
            System.out.println("Book not found (Linear Search).");
        }

        // Binary search by title
        searchTitle = "Pride and Prejudice";
        foundBook = library.binarySearchByTitle(searchTitle);
        if (foundBook != null) {
            System.out.println("Book found (Binary Search): " + foundBook.getTitle() +
                    " by " + foundBook.getAuthor());
        } else {
            System.out.println("Book not found (Binary Search).");
        }
    }
}
