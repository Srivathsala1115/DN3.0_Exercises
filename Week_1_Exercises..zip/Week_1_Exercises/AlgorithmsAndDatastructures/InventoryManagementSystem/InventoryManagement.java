package InventoryManagementSystem;

import java.util.HashMap;
import java.util.Map;

public class InventoryManagement {
    private Map<Integer, Product> inventory;

    public InventoryManagement() {
        this.inventory = new HashMap<>();
    }

    // Add a product to the inventory
    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }

    // Update a product in the inventory
    public void updateProduct(int productId, int newQuantity, double newPrice) {
        Product product = inventory.get(productId);
        if (product != null) {
            product.setQuantity(newQuantity);
            product.setPrice(newPrice);
        } else {
            System.out.println("Product not found.");
        }
    }

    // Delete a product from the inventory
    public void deleteProduct(int productId) {
        Product removedProduct = inventory.remove(productId);
        if (removedProduct == null) {
            System.out.println("Product not found.");
        }
    }

    // Display all products
    public void displayProducts() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }

    // Get a product by ID
    public Product getProduct(int productId) {
        return inventory.get(productId);
    }
}
