package InventoryManagementSystem;

public class Main {

    public static void main(String[] args) {
        // Initialize the InventoryManagement system
        InventoryManagement inventory = new InventoryManagement();

        // Add products
        inventory.addProduct(new Product(1, "Laptop", 10, 999.99));
        inventory.addProduct(new Product(2, "Smartphone", 15, 499.99));
        inventory.addProduct(new Product(3, "Tablet", 5, 299.99));

        // Display all products
        System.out.println("All products:");
        inventory.displayProducts();

        // Update a product
        inventory.updateProduct(2, 20, 479.99);
        System.out.println("\nAfter updating Smartphone:");
        inventory.displayProducts();

        // Delete a product
        inventory.deleteProduct(3);
        System.out.println("\nAfter deleting Tablet:");
        inventory.displayProducts();

        // Get a product by ID
        Product product = inventory.getProduct(1);
        System.out.println("\nProduct with ID 1: " + product);
    }
}
