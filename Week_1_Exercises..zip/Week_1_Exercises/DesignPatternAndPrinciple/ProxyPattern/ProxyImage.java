package ProxyPattern;
import java.util.HashMap;
import java.util.Map;

public class ProxyImage implements Image {
    private RealImage realImage;
    private String fileName;
    private static Map<String, RealImage> imageCache = new HashMap<>();

    public ProxyImage(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public void display() {
        if (imageCache.containsKey(fileName)) {
            System.out.println("Fetching " + fileName + " from cache.");
            realImage = imageCache.get(fileName);
        } else {
            realImage = new RealImage(fileName);
            imageCache.put(fileName, realImage);
        }
        realImage.display();
    }
}