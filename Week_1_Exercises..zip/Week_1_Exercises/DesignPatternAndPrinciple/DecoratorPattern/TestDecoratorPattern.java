package DecoratorPattern;

public class TestDecoratorPattern {
    public static void main(String[] args) {
        Notifier notifier = new EmailNotifier();
        notifier.send("System maintenance scheduled for midnight.");

        System.out.println("\n--- Adding SMS Notifier ---");
        Notifier smsNotifier = new SMSNotifierDecorator(notifier);
        smsNotifier.send("System maintenance scheduled for midnight.");

        System.out.println("\n--- Adding Slack Notifier ---");
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);
        slackNotifier.send("System maintenance scheduled for midnight.");
    }
}