package DecoratorPattern;

public class EmailNotifier implements Notifier {
    @Override
    public void send(String message) {
        String formattedMessage = formatMessage(message);
        System.out.println("Sending Email with message: " + formattedMessage);
        logNotification("Email", formattedMessage);
    }

    @Override
    public String formatMessage(String message) {
        return "Email: " + message;
    }

    private void logNotification(String type, String message) {
        System.out.println("Logged " + type + " notification: " + message);
    }
}
