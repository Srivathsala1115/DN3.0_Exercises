package DecoratorPattern;

public abstract class NotifierDecorator implements Notifier {
    protected Notifier wrappedNotifier;

    public NotifierDecorator(Notifier notifier) {
        this.wrappedNotifier = notifier;
    }

    @Override
    public void send(String message) {
        wrappedNotifier.send(message);
    }

    @Override
    public String formatMessage(String message) {
        return wrappedNotifier.formatMessage(message);
    }
}
