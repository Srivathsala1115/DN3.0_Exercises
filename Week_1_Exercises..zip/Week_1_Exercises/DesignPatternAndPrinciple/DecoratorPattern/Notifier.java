package DecoratorPattern;

public interface Notifier {
    void send(String message);
    String formatMessage(String message);
}
