package DecoratorPattern;

public class SlackNotifierDecorator extends NotifierDecorator {
    public SlackNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String message) {
        super.send(message);
        sendSlack(message);
    }

    @Override
    public String formatMessage(String message) {
        return "Slack: " + message;
    }

    private void sendSlack(String message) {
        String formattedMessage = formatMessage(message);
        System.out.println("Sending Slack message with: " + formattedMessage);
        logNotification("Slack", formattedMessage);
    }

    private void logNotification(String type, String message) {
        System.out.println("Logged " + type + " notification: " + message);
    }
}
