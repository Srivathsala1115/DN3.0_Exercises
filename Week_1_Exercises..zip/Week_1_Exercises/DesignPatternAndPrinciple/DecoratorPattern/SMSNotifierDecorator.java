package DecoratorPattern;

public class SMSNotifierDecorator extends NotifierDecorator {
    public SMSNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String message) {
        super.send(message);
        sendSMS(message);
    }

    @Override
    public String formatMessage(String message) {
        return "SMS: " + message;
    }

    private void sendSMS(String message) {
        String formattedMessage = formatMessage(message);
        System.out.println("Sending SMS with message: " + formattedMessage);
        logNotification("SMS", formattedMessage);
    }

    private void logNotification(String type, String message) {
        System.out.println("Logged " + type + " notification: " + message);
    }
}