package BuilderPattern;

public class TestComputerBuilder {
    public static void main(String[] args) {
        // Creating objects using Builder pattern
        Computer computer1 = new Computer.Builder("Intel i7", "16GB")
                .storage("1TB SSD")
                .gpu("NVIDIA RTX 3060")
                .motherboard("ASUS ROG")
                .powerSupply("750W Power Supply")
                .hasCoolingSystem(true)
                .build();

        Computer computer2 = new Computer.Builder("AMD Ryzen 5", "8GB")
                .build();

        // Printing computer details
        System.out.println(computer1);
        System.out.println(computer2);
    }
}


