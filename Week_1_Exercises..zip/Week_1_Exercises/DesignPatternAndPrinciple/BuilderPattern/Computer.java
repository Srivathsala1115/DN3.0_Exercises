package BuilderPattern;

// Computer.java
// Computer.java
public final class Computer {
    // Required parameters
    private final String cpu;
    private final String ram;

    // Optional parameters
    private final String storage;
    private final String gpu;
    private final String motherboard;
    private final String powerSupply;
    private final boolean hasCoolingSystem;

    // Private constructor to enforce Builder usage
    private Computer(Builder builder) {
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.storage = builder.storage;
        this.gpu = builder.gpu;
        this.motherboard = builder.motherboard;
        this.powerSupply = builder.powerSupply;
        this.hasCoolingSystem = builder.hasCoolingSystem;
    }

    // Getters
    public String getCpu() {
        return cpu;
    }

    public String getRam() {
        return ram;
    }

    public String getStorage() {
        return storage;
    }

    public String getGpu() {
        return gpu;
    }

    public String getMotherboard() {
        return motherboard;
    }

    public String getPowerSupply() {
        return powerSupply;
    }

    public boolean hasCoolingSystem() {
        return hasCoolingSystem;
    }

    @Override
    public String toString() {
        return "Computer Specifications:\n" +
                "CPU: " + cpu + "\n" +
                "RAM: " + ram + "\n" +
                "Storage: " + storage + "\n" +
                "GPU: " + gpu + "\n" +
                "Motherboard: " + motherboard + "\n" +
                "Power Supply: " + powerSupply + "\n" +
                "Cooling System: " + (hasCoolingSystem ? "Yes" : "No") + "\n";
    }

    // Builder class
    public static class Builder {
        // Required parameters
        private final String cpu;
        private final String ram;

        // Optional parameters - initialized to default values
        private String storage = "500GB HDD";
        private String gpu = "NVIDIA GTX 1650";
        private String motherboard = "Standard Motherboard";
        private String powerSupply = "500W Power Supply";
        private boolean hasCoolingSystem = false;

        public Builder(String cpu, String ram) {
            if (cpu == null || cpu.isEmpty() || ram == null || ram.isEmpty()) {
                throw new IllegalArgumentException("CPU and RAM are required fields.");
            }
            this.cpu = cpu;
            this.ram = ram;
        }

        public Builder storage(String storage) {
            this.storage = storage;
            return this;
        }

        public Builder gpu(String gpu) {
            this.gpu = gpu;
            return this;
        }

        public Builder motherboard(String motherboard) {
            this.motherboard = motherboard;
            return this;
        }

        public Builder powerSupply(String powerSupply) {
            this.powerSupply = powerSupply;
            return this;
        }

        public Builder hasCoolingSystem(boolean hasCoolingSystem) {
            this.hasCoolingSystem = hasCoolingSystem;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }

    // Test class

}
