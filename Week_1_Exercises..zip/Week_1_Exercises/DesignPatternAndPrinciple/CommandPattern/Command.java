package CommandPattern;
public interface Command {
    void execute();
    void undo();
}

