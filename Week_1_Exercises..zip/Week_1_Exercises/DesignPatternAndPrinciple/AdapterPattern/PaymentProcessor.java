package AdapterPattern;

public interface PaymentProcessor {
    void processPayment(String paymentDetails) throws PaymentProcessingException;
}

// Custom Exception for Payment Processing Errors
class PaymentProcessingException extends Exception {
    public PaymentProcessingException(String message) {
        super(message);
    }
}
