package AdapterPattern;

public class PaymentProcessorTest {
    public static void main(String[] args) {
        // Create instances of payment gateways
        PayPalGateway payPalGateway = new PayPalGateway();
        StripeGateway stripeGateway = new StripeGateway();

        // Create adapters for payment gateways
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalGateway);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripeGateway);

        // Process payments using adapters
        try {
            payPalAdapter.processPayment("Valid Payment details for PayPal");
            stripeAdapter.processPayment("Valid Payment details for Stripe");

            // Invalid payment details to demonstrate error handling
            stripeAdapter.processPayment("");
        } catch (PaymentProcessingException e) {
            System.err.println("Error processing payment: " + e.getMessage());
        }
    }
}
