package AdapterPattern;

// Adaptee Class for PayPal
class PayPalGateway {
    public void makePayment(String paymentDetails) {
        System.out.println("Processing payment through PayPal: " + paymentDetails);
    }
}

