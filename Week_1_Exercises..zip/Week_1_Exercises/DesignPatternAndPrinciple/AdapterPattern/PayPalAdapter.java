package AdapterPattern;

// Adapter Class for PayPal
class PayPalAdapter implements PaymentProcessor {
    private PayPalGateway payPalGateway;

    public PayPalAdapter(PayPalGateway payPalGateway) {
        this.payPalGateway = payPalGateway;
    }

    @Override
    public void processPayment(String paymentDetails) throws PaymentProcessingException {
        if (validatePaymentDetails(paymentDetails)) {
            payPalGateway.makePayment(paymentDetails);
            logTransaction("PayPal", paymentDetails);
        } else {
            throw new PaymentProcessingException("Invalid payment details for PayPal.");
        }
    }

    private boolean validatePaymentDetails(String paymentDetails) {
        // Simple validation logic (can be extended for more complex scenarios)
        return paymentDetails != null && !paymentDetails.trim().isEmpty();
    }

    private void logTransaction(String method, String paymentDetails) {
        System.out.println("Transaction logged for " + method + ": " + paymentDetails);
    }
}
