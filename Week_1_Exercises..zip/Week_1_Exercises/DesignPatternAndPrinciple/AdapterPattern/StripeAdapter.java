package AdapterPattern;

// Adapter Class for Stripe
class StripeAdapter implements PaymentProcessor {
    private StripeGateway stripeGateway;

    public StripeAdapter(StripeGateway stripeGateway) {
        this.stripeGateway = stripeGateway;
    }

    @Override
    public void processPayment(String paymentDetails) throws PaymentProcessingException {
        if (validatePaymentDetails(paymentDetails)) {
            stripeGateway.chargeCard(paymentDetails);
            logTransaction("Stripe", paymentDetails);
        } else {
            throw new PaymentProcessingException("Invalid payment details for Stripe.");
        }
    }

    private boolean validatePaymentDetails(String paymentDetails) {
        // Simple validation logic (can be extended for more complex scenarios)
        return paymentDetails != null && !paymentDetails.trim().isEmpty();
    }

    private void logTransaction(String method, String paymentDetails) {
        System.out.println("Transaction logged for " + method + ": " + paymentDetails);
    }
}

