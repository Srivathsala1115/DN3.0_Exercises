package AdapterPattern;

// Adaptee Class for Stripe
class StripeGateway {
    public void chargeCard(String paymentDetails) {
        System.out.println("Processing payment through Stripe: " + paymentDetails);
    }
}