package ObserverPattern;

public interface Stock {
    void registerObserver(Observer o);
    void deregisterObserver(Observer o);
    void notifyObservers();
    void setPrice(double price);
    double getPrice();
}

