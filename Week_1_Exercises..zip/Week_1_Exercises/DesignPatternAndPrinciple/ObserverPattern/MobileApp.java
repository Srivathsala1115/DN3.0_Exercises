package ObserverPattern;

public class MobileApp implements Observer {
    private String name;
    private int priority;

    public MobileApp(String name, int priority) {
        this.name = name;
        this.priority = priority;
    }

    @Override
    public void update(double price) {
        System.out.println("MobileApp " + name + " received stock price update: " + price);
    }

    @Override
    public int getPriority() {
        return priority;
    }
}
