package ObserverPattern;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class StockMarket implements Stock {
    private List<Observer> observers;
    private double price;
    private double lastPrice;

    public StockMarket() {
        observers = new ArrayList<>();
    }

    @Override
    public void registerObserver(Observer o) {
        observers.add(o);
        System.out.println(o.getClass().getSimpleName() + " registered.");
        sortObserversByPriority();
    }

    @Override
    public void deregisterObserver(Observer o) {
        observers.remove(o);
        System.out.println(o.getClass().getSimpleName() + " deregistered.");
    }

    @Override
    public void notifyObservers() {
        for (Observer o : observers) {
            o.update(price);
        }
        System.out.println("Observers notified of price change to: " + price);
    }

    @Override
    public void setPrice(double price) {
        if (Math.abs(this.price - price) > 0.1) { // Notify only if change > 0.1
            this.lastPrice = this.price;
            this.price = price;
            notifyObservers();
        } else {
            System.out.println("Price change too small to notify observers.");
        }
    }

    @Override
    public double getPrice() {
        return price;
    }

    private void sortObserversByPriority() {
        observers.sort(Comparator.comparingInt(Observer::getPriority));
    }
}
