package ObserverPattern;

public class WebApp implements Observer {
    private String name;
    private int priority;

    public WebApp(String name, int priority) {
        this.name = name;
        this.priority = priority;
    }

    @Override
    public void update(double price) {
        System.out.println("WebApp " + name + " received stock price update: " + price);
    }

    @Override
    public int getPriority() {
        return priority;
    }
}

