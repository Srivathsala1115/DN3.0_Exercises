package FactoryMethodPattern;

public interface Document {
    void open();
    void close();
    void save();
    void print();
}

