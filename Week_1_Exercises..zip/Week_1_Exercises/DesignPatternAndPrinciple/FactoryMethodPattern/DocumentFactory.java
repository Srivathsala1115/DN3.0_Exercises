package FactoryMethodPattern;

public interface DocumentFactory {
    Document createDocument();
}

