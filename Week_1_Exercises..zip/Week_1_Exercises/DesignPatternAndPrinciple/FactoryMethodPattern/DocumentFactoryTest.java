package FactoryMethodPattern;

public class DocumentFactoryTest {
    public static void main(String[] args) {
        testDocumentCreation(new WordDocumentFactory());
        testDocumentCreation(new PdfDocumentFactory());
        testDocumentCreation(new ExcelDocumentFactory());
    }

    private static void testDocumentCreation(DocumentFactory factory) {
        Document doc = factory.createDocument();
        doc.open();
        doc.save();
        doc.print();
        doc.close();
        System.out.println();
    }
}
