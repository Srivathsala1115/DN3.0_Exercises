package SingletonPattern;

// File: Logger.java
public class Logger {
    // The private static instance of Logger class
    private static volatile Logger instance;

    // Private constructor to prevent instantiation
    private Logger() {
        // Initialization code (e.g., setting up file paths, etc.)
        System.out.println("Logger initialized.");
    }

    // Public method to provide access to the instance
    public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }

    // Example method to demonstrate logging
    public void log(String message) {
        System.out.println("Log: " + message);
    }

    // Example method to demonstrate logging with levels
    public void log(String message, LogLevel level) {
        switch (level) {
            case INFO:
                System.out.println("INFO: " + message);
                break;
            case DEBUG:
                System.out.println("DEBUG: " + message);
                break;
            case ERROR:
                System.err.println("ERROR: " + message);
                break;
        }
    }

    // Enum to define log levels
    public enum LogLevel {
        INFO,
        DEBUG,
        ERROR
    }
}
