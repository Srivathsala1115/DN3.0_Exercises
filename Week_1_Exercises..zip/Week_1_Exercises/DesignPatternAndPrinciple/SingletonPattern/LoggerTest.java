package SingletonPattern;

// File: LoggerTest.java
public class LoggerTest {
    public static void main(String[] args) {
        // Get the single instance of Logger
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();

        // Check if both references point to the same instance
        if (logger1 == logger2) {
            System.out.println("Logger is a singleton!");
        } else {
            System.out.println("Different instances of Logger.");
        }

        // Test logging functionality
        logger1.log("This is a test message.");
        logger2.log("This is another test message.");

        // Test logging with different levels
        logger1.log("This is an INFO level message.", Logger.LogLevel.INFO);
        logger2.log("This is a DEBUG level message.", Logger.LogLevel.DEBUG);
        logger1.log("This is an ERROR level message.", Logger.LogLevel.ERROR);

        // Simulate multithreaded environment to test thread safety
        Thread thread1 = new Thread(() -> {
            Logger logger = Logger.getInstance();
            logger.log("Thread 1 logging.", Logger.LogLevel.INFO);
        });

        Thread thread2 = new Thread(() -> {
            Logger logger = Logger.getInstance();
            logger.log("Thread 2 logging.", Logger.LogLevel.DEBUG);
        });

        thread1.start();
        thread2.start();

        // Join threads to ensure they complete before finishing the main method
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
