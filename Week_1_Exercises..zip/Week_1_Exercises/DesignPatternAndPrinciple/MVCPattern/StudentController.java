
package MVCPattern;
import java.util.ArrayList;
import java.util.List;

public class StudentController {
    private List<Student> students;
    private StudentView view;

    public StudentController(StudentView view) {
        this.students = new ArrayList<>();
        this.view = view;
    }

    public void addStudent(Student student) {
        students.add(student);
        view.displayMessage("Student added successfully.");
    }

    public void updateStudent(String id, String name, String grade) {
        Student student = findStudentById(id);
        if(student != null) {
            student.setName(name);
            student.setGrade(grade);
            view.displayMessage("Student updated successfully.");
        } else {
            view.displayMessage("Student not found.");
        }
    }

    public void deleteStudent(String id) {
        Student student = findStudentById(id);
        if(student != null) {
            students.remove(student);
            view.displayMessage("Student deleted successfully.");
        } else {
            view.displayMessage("Student not found.");
        }
    }

    public void displayStudent(String id) {
        Student student = findStudentById(id);
        if(student != null) {
            view.displayStudentDetails(student);
        } else {
            view.displayMessage("Student not found.");
        }
    }

    public void displayAllStudents() {
        view.displayAllStudents(students);
    }

    private Student findStudentById(String id) {
        for(Student student : students) {
            if(student.getId().equals(id)) {
                return student;
            }
        }
        return null;
    }
}
