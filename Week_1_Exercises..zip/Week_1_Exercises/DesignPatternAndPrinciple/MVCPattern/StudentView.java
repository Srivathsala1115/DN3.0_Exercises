package MVCPattern;

import java.util.List;
public class StudentView {
    public void displayStudentDetails(Student student) {
        System.out.println("Student Details:");
        System.out.println("Name: " + student.getName());
        System.out.println("ID: " + student.getId());
        System.out.println("Grade: " + student.getGrade());
    }

    public void displayAllStudents(List<Student> students) {
        System.out.println("All Students:");
        for(Student student : students) {
            displayStudentDetails(student);
        }
    }

    public void displayMessage(String message) {
        System.out.println(message);
    }
}
