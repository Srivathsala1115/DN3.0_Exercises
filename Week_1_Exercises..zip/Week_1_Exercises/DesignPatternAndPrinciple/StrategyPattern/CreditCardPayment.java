package StrategyPattern;

public class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;
    private String cardHolderName;

    public CreditCardPayment(String cardNumber, String cardHolderName) {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
    }

    @Override
    public void pay(double amount) throws PaymentProcessingException {
        validate();
        System.out.println(amount + " paid using Credit Card.");
        // Additional logic for processing credit card payment
        logTransaction(amount);
    }

    @Override
    public void validate() throws PaymentProcessingException {
        if (cardNumber == null || cardNumber.length() != 16) {
            throw new PaymentProcessingException("Invalid credit card number.");
        }
        if (cardHolderName == null || cardHolderName.isEmpty()) {
            throw new PaymentProcessingException("Invalid card holder name.");
        }
    }

    private void logTransaction(double amount) {
        System.out.println("Credit Card transaction logged: " + amount);
    }
}

