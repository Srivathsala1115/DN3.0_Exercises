package StrategyPattern;

public interface PaymentStrategy {
    void pay(double amount) throws PaymentProcessingException;
    void validate() throws PaymentProcessingException;
}

// Custom exception for payment processing errors
class PaymentProcessingException extends Exception {
    public PaymentProcessingException(String message) {
        super(message);
    }
}

