package StrategyPattern;

public class PayPalPayment implements PaymentStrategy {
    private String email;

    public PayPalPayment(String email) {
        this.email = email;
    }

    @Override
    public void pay(double amount) throws PaymentProcessingException {
        validate();
        System.out.println(amount + " paid using PayPal.");
        // Additional logic for processing PayPal payment
        logTransaction(amount);
    }

    @Override
    public void validate() throws PaymentProcessingException {
        if (email == null || !email.contains("@")) {
            throw new PaymentProcessingException("Invalid PayPal email.");
        }
    }

    private void logTransaction(double amount) {
        System.out.println("PayPal transaction logged: " + amount);
    }
}