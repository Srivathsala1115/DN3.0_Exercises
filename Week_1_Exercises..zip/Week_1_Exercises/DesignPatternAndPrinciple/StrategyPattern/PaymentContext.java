package StrategyPattern;

public class PaymentContext {
    private PaymentStrategy paymentStrategy;
    private double discountRate;
    private double taxRate;

    public PaymentContext(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
        this.discountRate = 0.0;
        this.taxRate = 0.0;
    }

    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }

    public void pay(double amount) {
        try {
            double discountedAmount = applyDiscount(amount);
            double totalAmount = applyTax(discountedAmount);
            paymentStrategy.pay(totalAmount);
        } catch (PaymentProcessingException e) {
            System.err.println("Payment failed: " + e.getMessage());
        }
    }

    private double applyDiscount(double amount) {
        return amount - (amount * discountRate);
    }

    private double applyTax(double amount) {
        return amount + (amount * taxRate);
    }
}