package StrategyPattern;

public class StrategyPatternTest {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext(null);

        // Paying with Credit Card
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234567890123456", "John Doe");
        paymentContext.setPaymentStrategy(creditCardPayment);
        paymentContext.setDiscountRate(0.10); // 10% discount
        paymentContext.setTaxRate(0.05); // 5% tax
        paymentContext.pay(100.0);

        // Paying with PayPal
        PaymentStrategy payPalPayment = new PayPalPayment("johndoe@example.com");
        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.pay(150.0);
    }
}