package com.yourcompany.employeemanagementsystem.repository;

import com.yourcompany.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;

public interface EmployeeRepository extends JpaRepository<Employee, UUID> {

    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    Employee findByEmail(@Param("email") String email);

    // Find employees by first name
    List<Employee> findByFirstName(String firstName);

    // Find employees by last name
    List<Employee> findByLastName(String lastName);

    // Find employees by department
    List<Employee> findByDepartmentId(Long departmentId);

    // Find employees by last name containing a substring
    List<Employee> findByLastNameContaining(String substring);


    void clear();
}
