package com.yourcompany.employeemanagementsystem.repository;

import com.yourcompany.employeemanagementsystem.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    // Find departments by name
    List<Department> findByName(@Param("name") String name);

    // Find departments by name containing a substring
    List<Department> findByNameContaining(String substring);

    // Find departments with names starting with a specific prefix
    List<Department> findByNameStartingWith(String prefix);

}
