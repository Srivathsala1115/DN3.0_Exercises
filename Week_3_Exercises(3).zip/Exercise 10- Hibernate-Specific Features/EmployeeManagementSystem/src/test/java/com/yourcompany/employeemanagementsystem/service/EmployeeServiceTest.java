package com.yourcompany.employeemanagementsystem.service;

import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
public class EmployeeServiceTest {

    @Autowired
    private EmployeeService employeeService;

    @MockBean
    private EmployeeRepository employeeRepository;

    private Employee employee1;
    private Employee employee2;
    private Employee employee3;

    @BeforeEach
    void setUp() {
        UUID id1 = UUID.randomUUID();
        UUID id2 = UUID.randomUUID();
        UUID id3 = UUID.randomUUID();

        employee1 = new Employee();
        employee1.setId(id1);
        employee1.setEmail("john.doe@example.com");
        employee1.setFirstName("John");
        employee1.setLastName("Doe");

        employee2 = new Employee();
        employee2.setId(id2);
        employee2.setEmail("jane.doe@example.com");
        employee2.setFirstName("Jane");
        employee2.setLastName("Doe");

        employee3 = new Employee();
        employee3.setId(id3);
        employee3.setEmail("jim.doe@example.com");
        employee3.setFirstName("Jim");
        employee3.setLastName("Doe");

        // Configure mock repository behavior
        when(employeeRepository.save(any(Employee.class))).thenAnswer(invocation -> {
            Employee employee = invocation.getArgument(0);
            // Simulate auto-generated ID assignment for the mock
            if (employee.getId() == null) {
                employee.setId(UUID.randomUUID());
            }
            return employee;
        });

        when(employeeRepository.findById(id1)).thenReturn(Optional.of(employee1));
        when(employeeRepository.findById(id2)).thenReturn(Optional.of(employee2));
        when(employeeRepository.findById(id3)).thenReturn(Optional.of(employee3));

        when(employeeRepository.findByEmail("john.doe@example.com")).thenReturn(employee1);
        when(employeeRepository.findByEmail("jane.doe@example.com")).thenReturn(employee2);
        when(employeeRepository.findByEmail("jim.doe@example.com")).thenReturn(employee3);

        // Mock behavior for saveAll
        when(employeeRepository.saveAll(anyIterable())).thenReturn(List.of(employee1, employee2, employee3));
    }

    @Test
    void testSaveEmployeesInBatch() {
        List<Employee> employees = List.of(employee1, employee2, employee3);

        employeeService.saveEmployeesInBatch(employees);

        verify(employeeRepository, times(3)).save(any(Employee.class));
        verify(employeeRepository, times(1)).flush(); // Ensure flush was called for batch processing
    }

    @Test
    void testSaveEmployee() {
        Employee newEmployee = new Employee();
        newEmployee.setEmail("new.employee@example.com");
        newEmployee.setFirstName("New");
        newEmployee.setLastName("Employee");

        when(employeeRepository.save(newEmployee)).thenReturn(newEmployee);

        Employee savedEmployee = employeeService.saveEmployee(newEmployee);

        verify(employeeRepository, times(1)).save(newEmployee);
        assertThat(savedEmployee).isEqualTo(newEmployee);
    }

    @Test
    void testGetEmployeeById() {
        Employee foundEmployee = employeeService.getEmployeeById(employee1.getId());

        verify(employeeRepository, times(1)).findById(employee1.getId());
        assertThat(foundEmployee).isEqualTo(employee1);
    }

    @Test
    void testGetEmployeeByEmail() {
        Employee foundEmployee = employeeService.getEmployeeByEmail("john.doe@example.com");

        verify(employeeRepository, times(1)).findByEmail("john.doe@example.com");
        assertThat(foundEmployee).isEqualTo(employee1);
    }
}