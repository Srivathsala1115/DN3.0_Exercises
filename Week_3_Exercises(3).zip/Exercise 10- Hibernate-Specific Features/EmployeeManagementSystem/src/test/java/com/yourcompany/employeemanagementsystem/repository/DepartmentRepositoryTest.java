package com.yourcompany.employeemanagementsystem.repository;
import com.yourcompany.employeemanagementsystem.entity.Department;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class DepartmentRepositoryTest {
        @Autowired
        private DepartmentRepository departmentRepository;

        private Department department1;
        private Department department2;
        private Department department3;

        @BeforeEach
        void setUp() {
            // Initialize departments with different names
            department1 = new Department();
            department1.setName("Engineering");
            departmentRepository.save(department1);

            department2 = new Department();
            department2.setName("Finance");
            departmentRepository.save(department2);

            department3 = new Department();
            department3.setName("Engineering and Development");
            departmentRepository.save(department3);
        }

        @Test
        void testFindByName() {
            List<Department> departments = departmentRepository.findByName("Engineering");
            assertThat(departments).hasSize(2);
            assertThat(departments).contains(department1, department3);
        }

        @Test
        void testFindByNameContaining() {
            List<Department> departments = departmentRepository.findByNameContaining("Eng");
            assertThat(departments).hasSize(2);
            assertThat(departments).contains(department1, department3);
        }

        @Test
        void testFindByNameStartingWith() {
            List<Department> departments = departmentRepository.findByNameStartingWith("Engine");
            assertThat(departments).hasSize(2);
            assertThat(departments).contains(department1, department3);
        }
    }

