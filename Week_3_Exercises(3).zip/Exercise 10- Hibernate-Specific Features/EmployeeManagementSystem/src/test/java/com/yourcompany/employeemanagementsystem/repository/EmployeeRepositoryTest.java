package com.yourcompany.employeemanagementsystem.repository;

import com.yourcompany.employeemanagementsystem.entity.Department;
import com.yourcompany.employeemanagementsystem.entity.Employee;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
@SpringBootTest
@AutoConfigureMockMvc
public class EmployeeRepositoryTest {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    private Department department;

    @BeforeEach
    void setUp() {
        department = new Department();
        department.setName("Engineering");
        department = departmentRepository.save(department);

        Employee employee = new Employee();
        employee.setEmail("john.doe@example.com");
        employee.setFirstName("John");
        employee.setLastName("Doe");
        employee.setDepartment(department);
        employeeRepository.save(employee);
    }

    @Test
    void testFindByEmail() {
        Employee foundEmployee = employeeRepository.findByEmail("john.doe@example.com");
        assertThat(foundEmployee).isNotNull();
        assertThat(foundEmployee.getEmail()).isEqualTo("john.doe@example.com");
    }

    @Test
    void testFullName() {
        Employee foundEmployee = employeeRepository.findByEmail("john.doe@example.com");
        assertThat(foundEmployee).isNotNull();
        assertThat(foundEmployee.getFullName()).isEqualTo("John Doe");
    }

    @Test
    @Transactional
    void testBatchProcessing() {
        // Create a list of employees
        List<Employee> employees = List.of(
                new Employee("vaths@example.com", "Srivaths", "One", department),
                new Employee("adi2@example.com", "Adi", "Two", department),
                new Employee("yuvi3@example.com", "Yuvi", "Three", department)
        );

        // Save employees in batch
        employeeRepository.saveAll(employees);

        // Verify that all employees are saved
        assertThat(employeeRepository.count()).isEqualTo(4); // Assuming the initial employee was saved already

        // Optionally, check individual employees if needed
        assertThat(employeeRepository.findByEmail("employee1@example.com")).isNotNull();
        assertThat(employeeRepository.findByEmail("employee2@example.com")).isNotNull();
        assertThat(employeeRepository.findByEmail("employee3@example.com")).isNotNull();
    }
}
