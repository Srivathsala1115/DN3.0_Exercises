package com.yourcompany.employeemanagementsystem;

import com.yourcompany.employeemanagementsystem.controller.EmployeeController;
import com.yourcompany.employeemanagementsystem.entity.Department;
import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.repository.DepartmentRepository;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import com.yourcompany.employeemanagementsystem.service.EmployeeService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class EmployeeManagementSystemApplicationTests {

	@Autowired
	private EmployeeController employeeController;

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private DepartmentRepository departmentRepository;

	@Test
	void contextLoads() {
		// Basic context loading test
		assertNotNull(employeeController);
		assertNotNull(employeeService);
		assertNotNull(employeeRepository);
		assertNotNull(departmentRepository);
	}

	@Test
	void testCreateEmployee() {
		// Create a new department
		Department department = new Department();
		department.setName("Human Resources");
		department = departmentRepository.save(department);

		// Create a new employee
		Employee employee = new Employee();
		employee.setName("John Doe");
		employee.setDepartment(department);

		// Save the employee
		Employee savedEmployee = employeeRepository.save(employee);

		// Verify the employee was saved
		assertNotNull(savedEmployee);
		assertEquals("John Doe", savedEmployee.getName());
		assertEquals(department.getId(), savedEmployee.getDepartment().getId());
	}

	@Test
	void testFindEmployeeById() {
		// Create and save a department
		Department department = new Department();
		department.setName("Finance");
		department = departmentRepository.save(department);

		// Create and save an employee
		Employee employee = new Employee();
		employee.setName("John Smith");
		employee.setDepartment(department);
		employee = employeeRepository.save(employee);

		// Now try to find the employee by ID
		Optional<Employee> foundEmployee = employeeRepository.findById(employee.getId());

		// Verify the employee was found
		assertThat(foundEmployee).isPresent();
		assertEquals(employee.getId(), foundEmployee.get().getId());
		assertEquals("John Smith", foundEmployee.get().getName());
	}

	@Test
	void testFindAllEmployees() {
		// Create and save a department
		Department department = new Department();
		department.setName("Finance");
		department = departmentRepository.save(department);

		// Create and save employees
		Employee employee1 = new Employee();
		employee1.setName("Alice");
		employee1.setDepartment(department);
		employeeRepository.save(employee1);

		Employee employee2 = new Employee();
		employee2.setName("Bob");
		employee2.setDepartment(department);
		employeeRepository.save(employee2);

		// Find all employees
		List<Employee> employees = employeeRepository.findAll();

		// Verify the list is not empty
		assertThat(employees).isNotEmpty();
		assertThat(employees).hasSize(2); // Optional: Verify the number of employees
	}


	@Test
	void testUpdateEmployee() {
		// Create and save a new department
		Department department = new Department();
		department.setName("Finance");
		department = departmentRepository.save(department);

		// Create and save a new employee
		Employee employee = new Employee();
		employee.setName("Jane Doe");
		employee.setDepartment(department);
		employee = employeeRepository.save(employee);

		// Update the employee's name
		employee.setName("Jane Smith");
		Employee updatedEmployee = employeeRepository.save(employee);

		// Verify the employee's name was updated
		assertEquals("Jane Smith", updatedEmployee.getName());
	}

	@Test
	void testDeleteEmployee() {
		// Create and save a new employee
		Employee employee = new Employee();
		employee.setName("Mark Johnson");

		// Create and save a new department
		Department department = new Department();
		department.setName("IT");
		department = departmentRepository.save(department);
		employee.setDepartment(department);

		employee = employeeRepository.save(employee);

		// Delete the employee
		employeeRepository.deleteById(employee.getId());

		// Verify the employee was deleted
		Optional<Employee> deletedEmployee = employeeRepository.findById(employee.getId());
		assertThat(deletedEmployee).isNotPresent();
	}

	@Test
	void testEmployeeServiceGetEmployeeNamesAndDepartments() {
		// Assuming some employees exist in the database
		List<?> employeeNamesAndDepartments = employeeService.getEmployeeNamesAndDepartments();

		// Verify the list is not empty
		assertThat(employeeNamesAndDepartments).isNotEmpty();
	}
}
