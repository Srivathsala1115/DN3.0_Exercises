package com.yourcompany.employeemanagementsystem.controller;

import com.yourcompany.employeemanagementsystem.projection.EmployeeNameAndDepartment;
import com.yourcompany.employeemanagementsystem.projection.EmployeeInfo;
import com.yourcompany.employeemanagementsystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/names-and-departments")
    public List<EmployeeNameAndDepartment> getEmployeeNamesAndDepartments() {
        return employeeService.getEmployeeNamesAndDepartments();
    }

    @GetMapping("/info")
    public List<EmployeeInfo> getEmployeeInfo() {
        return employeeService.getEmployeeInfo();
    }
}
