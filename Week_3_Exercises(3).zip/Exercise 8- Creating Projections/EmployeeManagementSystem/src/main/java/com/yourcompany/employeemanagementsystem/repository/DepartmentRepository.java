package com.yourcompany.employeemanagementsystem.repository;

import com.yourcompany.employeemanagementsystem.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    // Custom query to find departments by name (case insensitive)
    List<Department> findByNameIgnoreCase(String name);

    // Custom query using @Query to find departments that have a name containing a specific keyword
    @Query("SELECT d FROM Department d WHERE d.name LIKE %:keyword%")
    List<Department> findDepartmentsByNameContaining(@Param("keyword") String keyword);

    // Custom query using @Query to find departments by a list of department names
    @Query("SELECT d FROM Department d WHERE d.name IN :names")
    List<Department> findDepartmentsByNames(@Param("names") List<String> names);

    // Custom query to count the number of departments that have a name containing a specific keyword
    @Query("SELECT COUNT(d) FROM Department d WHERE d.name LIKE %:keyword%")
    long countDepartmentsByNameContaining(@Param("keyword") String keyword);

    // Custom query to delete departments by name (case insensitive)
    void deleteByNameIgnoreCase(String name);
}
