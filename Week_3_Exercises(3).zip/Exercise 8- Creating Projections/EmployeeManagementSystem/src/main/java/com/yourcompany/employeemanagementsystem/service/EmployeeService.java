package com.yourcompany.employeemanagementsystem.service;

import com.yourcompany.employeemanagementsystem.projection.EmployeeNameAndDepartment;
import com.yourcompany.employeemanagementsystem.projection.EmployeeInfo;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<EmployeeNameAndDepartment> getEmployeeNamesAndDepartments() {
        return employeeRepository.findEmployeeNameAndDepartment();
    }

    public List<EmployeeInfo> getEmployeeInfo() {
        return employeeRepository.findEmployeeInfo();
    }
}
