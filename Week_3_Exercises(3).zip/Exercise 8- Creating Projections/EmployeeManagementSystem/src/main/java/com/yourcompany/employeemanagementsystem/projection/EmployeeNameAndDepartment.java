package com.yourcompany.employeemanagementsystem.projection;

public interface EmployeeNameAndDepartment {
    String getEmployeeName();
    String getDepartmentName();
}
