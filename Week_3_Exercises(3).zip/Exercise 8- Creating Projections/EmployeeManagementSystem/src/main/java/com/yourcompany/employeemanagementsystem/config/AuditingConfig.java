package com.yourcompany.employeemanagementsystem.config;

import com.yourcompany.employeemanagementsystem.entity.Department;
import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.repository.DepartmentRepository;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

@Component
public class AuditingConfig {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @PostConstruct
    public void init() {
        // Create and save a department
        Department department = new Department();
        department.setName("Human Resources");
        department = departmentRepository.save(department);

        // Create and save employees
        Employee employee1 = new Employee();
        employee1.setName("Adi");
        employee1.setDepartment(department);
        employeeRepository.save(employee1);

        Employee employee2 = new Employee();
        employee2.setName("Srivaths");
        employee2.setDepartment(department);
        employeeRepository.save(employee2);
    }
}
