package com.yourcompany.employeemanagementsystem.repository;

import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.projection.EmployeeNameAndDepartment;
import com.yourcompany.employeemanagementsystem.projection.EmployeeInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query("SELECT e.name AS employeeName, d.name AS departmentName FROM Employee e JOIN e.department d")
    List<EmployeeNameAndDepartment> findEmployeeNameAndDepartment();

    @Query("SELECT new com.yourcompany.employeemanagementsystem.projection.EmployeeInfo(e.name, d.name) FROM Employee e JOIN e.department d")
    List<EmployeeInfo> findEmployeeInfo();
}
