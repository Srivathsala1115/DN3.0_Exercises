package com.yourcompany.employeemanagementsystem;

import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import com.yourcompany.employeemanagementsystem.service.EmployeeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmployeeServiceTests {

    @InjectMocks
    private EmployeeService employeeService;

    @Mock
    private EmployeeRepository employeeRepository;

    @BeforeEach

    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetEmployees() {
        // Arrange
        Employee employee = new Employee();
        employee.setId(1L);
        employee.setName("John Doe");

        Page<Employee> employees = new PageImpl<>(Collections.singletonList(employee));
        Pageable pageable = Pageable.unpaged();

        when(employeeRepository.findAll(pageable)).thenReturn(employees);

        // Act
        Page<Employee> result = employeeService.getEmployees(pageable);

        // Assert
        assertEquals(1, result.getTotalElements());
        assertEquals("John Doe", result.getContent().get(0).getName());
        verify(employeeRepository, times(1)).findAll(pageable);
    }

    @Test
    void testGetEmployeeById() {
        // Arrange
        Employee employee = new Employee();
        employee.setId(1L);
        employee.setName("John Doe");

        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));

        // Act
        Optional<Employee> result = employeeService.getEmployeeById(1L);

        // Assert
        assertEquals("John Doe", result.get().getName());
        verify(employeeRepository, times(1)).findById(1L);
    }

    @Test
    void testCreateEmployee() {
        // Arrange
        Employee newEmployee = new Employee("John Doe", "Developer");
        Employee savedEmployee = new Employee("John Doe", "Developer");
        savedEmployee.setSalary(50000.0); // Assuming that the salary is set somewhere in the service

        when(employeeRepository.save(newEmployee)).thenReturn(savedEmployee);

        // Act
        Employee result = employeeService.createEmployee(newEmployee);

        // Assert
        assertNotNull(result, "Employee should not be null");
        assertEquals("John Doe", result.getName());
        assertEquals("Developer", result.getRole());
        assertEquals(50000.0, result.getSalary(), 0.0); // Adding a delta for floating-point comparison

        verify(employeeRepository, times(1)).save(newEmployee);
    }



}
