package com.yourcompany.employeemanagementsystem;

import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class EmployeeRepositoryTest {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Test
    public void testFindByLastName() {
        // Given
        Employee employee1 = new Employee("John", "Doe", "john.doe@example.com");
        Employee employee2 = new Employee("Jane", "Doe", "jane.doe@example.com");
        employeeRepository.save(employee1);
        employeeRepository.save(employee2);

        // When
        List<Employee> result = employeeRepository.findByLastName("Doe");

        // Then
        assertThat(result).hasSize(2);
        assertThat(result).extracting(Employee::getFirstName).containsExactlyInAnyOrder("John", "Jane");
    }

    @Test
    public void testPagination() {
        // Given
        for (int i = 1; i <= 10; i++) {
            employeeRepository.save(new Employee("Employee" + i, "LastName", "email" + i + "@example.com"));
        }

        // When
        PageRequest pageRequest = PageRequest.of(0, 5);
        List<Employee> result = employeeRepository.findAll(pageRequest).getContent();

        // Then
        assertThat(result).hasSize(5);
        assertThat(result).extracting(Employee::getFirstName).contains("Employee1", "Employee2", "Employee3", "Employee4", "Employee5");
    }

    @Test
    public void testSorting() {
        // Given
        employeeRepository.save(new Employee("Charlie", "Brown", "charlie.brown@example.com"));
        employeeRepository.save(new Employee("Alice", "Wonderland", "alice.wonderland@example.com"));
        employeeRepository.save(new Employee("Bob", "Marley", "bob.marley@example.com"));

        // When
        Sort sort = Sort.by("firstName").ascending();
        List<Employee> result = employeeRepository.findAll(sort);

        // Then
        assertThat(result).hasSize(3);
        assertThat(result.get(0).getFirstName()).isEqualTo("Alice");
        assertThat(result.get(1).getFirstName()).isEqualTo("Bob");
        assertThat(result.get(2).getFirstName()).isEqualTo("Charlie");
    }
}
