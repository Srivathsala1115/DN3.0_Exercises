package com.yourcompany.employeemanagementsystem.repository;

import com.yourcompany.employeemanagementsystem.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

    // Find departments by name
    List<Department> findByName(String name);

    // Check if a department exists by name
    boolean existsByName(String name);

    // Custom query to find departments by name using JPQL
    @Query("SELECT d FROM Department d WHERE d.name = :name")
    List<Department> findDepartmentsByName(@Param("name") String name);

    // Custom query to find departments with names containing a specific substring
    @Query("SELECT d FROM Department d WHERE d.name LIKE %:substring%")
    List<Department> findDepartmentsByNameContaining(@Param("substring") String substring);

    // Custom query to count departments
    @Query("SELECT COUNT(d) FROM Department d")
    long countDepartments();

    // Native query to find departments by name
    @Query(value = "SELECT * FROM department WHERE name = :name", nativeQuery = true)
    List<Department> findDepartmentsByNameNative(@Param("name") String name);
}
