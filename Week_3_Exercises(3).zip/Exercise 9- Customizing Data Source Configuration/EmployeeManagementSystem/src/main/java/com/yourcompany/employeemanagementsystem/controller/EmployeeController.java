package com.yourcompany.employeemanagementsystem.controller;

import com.yourcompany.employeemanagementsystem.entity.Department;
import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.service.DepartmentService;
import com.yourcompany.employeemanagementsystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private DepartmentService departmentService;

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Employee> getEmployeeById(@PathVariable Long id) {
        return employeeService.findById(id);
    }

    @PostMapping
    public Employee createEmployee(@RequestBody Employee employee) {
        // Assuming the department ID is passed and needs to be resolved
        if (employee.getDepartment() != null && employee.getDepartment().getId() != null) {
            Department department = departmentService.findById(employee.getDepartment().getId()).orElse(null);
            employee.setDepartment(department);
        }
        return employeeService.save(employee);
    }

    @PutMapping("/{id}")
    public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
        employee.setId(id);
        // Assuming the department ID is passed and needs to be resolved
        if (employee.getDepartment() != null && employee.getDepartment().getId() != null) {
            Department department = departmentService.findById(employee.getDepartment().getId()).orElse(null);
            employee.setDepartment(department);
        }
        return employeeService.save(employee);
    }

    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable Long id) {
        employeeService.deleteById(id);
    }

    @GetMapping("/search/by-name")
    public List<Employee> findEmployeesByName(@RequestParam String name) {
        return employeeService.findEmployeesByName(name);
    }

    @GetMapping("/search/by-department")
    public List<Employee> findEmployeesByDepartment(@RequestParam Long departmentId) {
        Department department = departmentService.findById(departmentId).orElse(null);
        return employeeService.findEmployeesByDepartment(department);
    }

    @GetMapping("/search/by-name-containing")
    public List<Employee> findEmployeesByNameContaining(@RequestParam String substring) {
        return employeeService.findEmployeesByNameContaining(substring);
    }

    @GetMapping("/count")
    public long countEmployees() {
        return employeeService.countEmployees();
    }
}
