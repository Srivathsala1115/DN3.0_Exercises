package com.yourcompany.employeemanagementsystem.projection;

public class EmployeeInfo {
    private String employeeName;
    private String departmentName;

    public EmployeeInfo(String employeeName, String departmentName) {
        this.employeeName = employeeName;
        this.departmentName = departmentName;
    }

    public String getEmployeeInfo() {
        return this.employeeName + " works in " + this.departmentName + " department.";
    }

    // Getters
    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }
}
