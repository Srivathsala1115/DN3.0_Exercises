package com.yourcompany.employeemanagementsystem.repository;

import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Find employees by name
    List<Employee> findByName(String name);

    // Find employees by department
    List<Employee> findByDepartment(Department department); // Use Department object

    // Find employees with names containing a specific substring
    List<Employee> findByNameContaining(String substring);
}
