package com.yourcompany.employeemanagementsystem.service;

import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.entity.Department;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    // Find all employees
    public List<Employee> findAll() {
        return employeeRepository.findAll();
    }

    // Find employee by ID
    public Optional<Employee> findById(Long id) {
        return employeeRepository.findById(id);
    }

    // Save or update an employee
    public Employee save(Employee employee) {
        return employeeRepository.save(employee);
    }

    // Delete an employee by ID
    public void deleteById(Long id) {
        employeeRepository.deleteById(id);
    }

    // Find employees by name
    public List<Employee> findEmployeesByName(String name) {
        return employeeRepository.findByName(name);
    }

    // Find employees by department
    public List<Employee> findEmployeesByDepartment(Department department) {
        return employeeRepository.findByDepartment(department);
    }

    // Find employees with names containing a specific substring
    public List<Employee> findEmployeesByNameContaining(String substring) {
        return employeeRepository.findByNameContaining(substring);
    }

    // Count the total number of employees
    public long countEmployees() {
        return employeeRepository.count();
    }
}
