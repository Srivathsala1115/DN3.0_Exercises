package com.yourcompany.employeemanagementsystem;

import com.yourcompany.employeemanagementsystem.entity.Department;
import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.repository.DepartmentRepository;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import com.yourcompany.employeemanagementsystem.service.DepartmentService;
import com.yourcompany.employeemanagementsystem.service.EmployeeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class EmployeeServiceTests {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @BeforeEach
    public void setUp() {
        // Clear the repositories before each test
        employeeRepository.deleteAll();
        departmentRepository.deleteAll();
    }

    private Department createAndSaveDepartment(String name) {
        Department department = new Department();
        department.setName(name);
        return departmentService.save(department);
    }

    @Test
    public void testCreateEmployee() {
        Department department = createAndSaveDepartment("Engineering");

        Employee employee = new Employee();
        employee.setName("John Doe");
        employee.setDepartment(department);
        Employee savedEmployee = employeeService.save(employee);

        assertThat(savedEmployee).isNotNull();
        assertThat(savedEmployee.getId()).isNotNull();
        assertThat(savedEmployee.getName()).isEqualTo("John Doe");
        assertThat(savedEmployee.getDepartment()).isEqualTo(department);
    }

    @Test
    public void testFindAllEmployees() {
        Department department1 = createAndSaveDepartment("Engineering");
        Department department2 = createAndSaveDepartment("Marketing");

        Employee employee1 = new Employee();
        employee1.setName("John Doe");
        employee1.setDepartment(department1);
        employeeService.save(employee1);

        Employee employee2 = new Employee();
        employee2.setName("Jane Doe");
        employee2.setDepartment(department2);
        employeeService.save(employee2);

        List<Employee> employees = employeeService.findAll();
        assertThat(employees).isNotEmpty();
        assertThat(employees).hasSize(2);
    }

    @Test
    public void testFindEmployeeById() {
        Department department = createAndSaveDepartment("Engineering");

        Employee employee = new Employee();
        employee.setName("John Doe");
        employee.setDepartment(department);
        Employee savedEmployee = employeeService.save(employee);

        Optional<Employee> foundEmployee = employeeService.findById(savedEmployee.getId());
        assertThat(foundEmployee).isPresent();
        assertThat(foundEmployee.get().getName()).isEqualTo("John Doe");
        assertThat(foundEmployee.get().getDepartment()).isEqualTo(department);
    }

    @Test
    public void testFindEmployeesByName() {
        Department department = createAndSaveDepartment("Engineering");

        Employee employee1 = new Employee();
        employee1.setName("John Doe");
        employee1.setDepartment(department);
        employeeService.save(employee1);

        Employee employee2 = new Employee();
        employee2.setName("John Smith");
        employee2.setDepartment(department);
        employeeService.save(employee2);

        List<Employee> employees = employeeService.findEmployeesByName("John Doe");
        assertThat(employees).hasSize(1);
        assertThat(employees.get(0).getName()).isEqualTo("John Doe");
    }

    @Test
    public void testFindEmployeesByNameContaining() {
        Department department = createAndSaveDepartment("Engineering");

        Employee employee1 = new Employee();
        employee1.setName("John Doe");
        employee1.setDepartment(department);
        employeeService.save(employee1);

        Employee employee2 = new Employee();
        employee2.setName("Johnny Depp");
        employee2.setDepartment(department);
        employeeService.save(employee2);

        List<Employee> employees = employeeService.findEmployeesByNameContaining("John");
        assertThat(employees).hasSize(2);
    }

    @Test
    public void testCountEmployees() {
        Department department = createAndSaveDepartment("Engineering");

        Employee employee1 = new Employee();
        employee1.setName("John Doe");
        employee1.setDepartment(department);
        employeeService.save(employee1);

        Employee employee2 = new Employee();
        employee2.setName("Jane Doe");
        employee2.setDepartment(department);
        employeeService.save(employee2);

        long count = employeeService.countEmployees();
        assertThat(count).isEqualTo(2);
    }
}
