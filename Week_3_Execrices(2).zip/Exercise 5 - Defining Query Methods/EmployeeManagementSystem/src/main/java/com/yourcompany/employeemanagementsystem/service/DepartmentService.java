package com.yourcompany.employeemanagementsystem.service;

import com.yourcompany.employeemanagementsystem.entity.Department;
import com.yourcompany.employeemanagementsystem.repository.DepartmentRepository;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Transactional
    public void deleteDepartment(Long departmentId) {
        if (departmentRepository.existsById(departmentId)) {
            employeeRepository.deleteByDepartmentId(departmentId);
            departmentRepository.deleteById(departmentId);
        } else {
            throw new EntityNotFoundException("Department not found with id: " + departmentId);
        }
    }

    public Department createDepartment(Department department) {
        return departmentRepository.save(department);
    }

    public Department updateDepartment(Long id, Department department) {
        // Find the existing department by ID
        Department existingDepartment = departmentRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Department not found with id: " + id));

        // Update the department's properties
        existingDepartment.setName(department.getName());

        // Save the updated department back to the repository
        return departmentRepository.save(existingDepartment);
    }


    public Department getDepartmentById(Long id) {
        // Find and return the department by ID
        return departmentRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Department not found with id: " + id));
    }

}
