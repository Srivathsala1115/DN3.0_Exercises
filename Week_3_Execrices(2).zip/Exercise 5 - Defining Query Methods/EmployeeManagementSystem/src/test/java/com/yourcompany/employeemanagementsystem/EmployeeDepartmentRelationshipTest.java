package com.yourcompany.employeemanagementsystem;

import com.yourcompany.employeemanagementsystem.entity.Department;
import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.repository.DepartmentRepository;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@SpringBootTest
@Transactional
public class EmployeeDepartmentRelationshipTest {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Test
    public void testAddEmployeesToExistingDepartment() {
        // Create and save a department first
        Department department = new Department();
        department.setName("HR");
        department = departmentRepository.save(department);  // Save department and get it back with ID

        // Create new employees
        Employee emp3 = new Employee(null, "Alice Brown", "alice@example.com", department);

        // Save employee (should automatically link with the department)
        Employee savedEmployee = employeeRepository.save(emp3);

        // Assertions
        Assertions.assertNotNull(savedEmployee.getId());
        Assertions.assertEquals("HR", savedEmployee.getDepartment().getName());
    }

    @Test
    public void testFetchEmployeesWithDepartment() {
        // Create and save a department
        Department department = new Department();
        department.setName("HR");
        department = departmentRepository.save(department);

        // Create new employees and associate them with the department
        Employee emp1 = new Employee(null, "John Doe", "john@example.com", department);
        employeeRepository.save(emp1);

        // Fetch all employees
        List<Employee> employees = employeeRepository.findAll();

        // Assertions
        Assertions.assertFalse(employees.isEmpty());
        Assertions.assertNotNull(employees.get(0).getDepartment());
    }

}
